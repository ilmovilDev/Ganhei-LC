import { PrismaClient } from "@/generated/prisma/client";
import { AppError } from "@/lib/errors/app-error";
import { prisma } from "@/lib/db/prisma";
import { dayDateToDatabase } from "@/shared/lib/date/day-date";
import { createDaySchema } from "../schemas/create-day.schema";
import { syncDayFinancialState } from "../services/sync-day-financial-state.service";
import { CreateDayInput } from "../../types";
import { DayRepository } from "../../infrastructure/repositories/day.repository";
import { toDayDto } from "../../infrastructure/mappers/day.mapper";
import { DayListItemDto } from "../dtos";
import { DayRepositoryContract } from "../../domain/contracts/day-repository.contract";
import { APP_ERROR_CODES } from "@/lib/errors/app-error-code";
import { ERROR_MESSAGES } from "@/shared/constants/error-messages";

interface CreateDayUseCaseRequest {
  clerkId: string;
  data: CreateDayInput;
}

export class CreateDayUseCase {
  constructor(private readonly db: PrismaClient = prisma) {}

  async execute({
    clerkId,
    data,
  }: Readonly<CreateDayUseCaseRequest>): Promise<DayListItemDto> {
    // ─────────────────────────────────────
    // VALIDATION
    // ─────────────────────────────────────
    const validatedData = createDaySchema.parse(data);

    // ─────────────────────────────────────
    // NORMALIZE DATE
    // ─────────────────────────────────────
    const databaseDate = dayDateToDatabase(validatedData.date);

    // ─────────────────────────────────────
    // TRANSACTION
    // ─────────────────────────────────────
    return this.db.$transaction(async (tx) => {
      const repository: DayRepositoryContract = new DayRepository(tx);

      // ───────────────────────────────────
      // DUPLICATE CHECK
      // ───────────────────────────────────
      const alreadyExists = await repository.existsByDate({
        clerkId,
        date: databaseDate,
      });

      if (alreadyExists) {
        throw new AppError({
          code: APP_ERROR_CODES.DAY_ALREADY_EXISTS,
          message: ERROR_MESSAGES.DAY_ALREADY_EXISTS,
          statusCode: 409,
        });
      }

      // ───────────────────────────────────
      // CREATE BASE DAY
      // ───────────────────────────────────
      const createdDay = await repository.create({
        clerkId,
        date: databaseDate,
        hours: validatedData.hours,
        kilometers: validatedData.kilometers,
      });

      // ───────────────────────────────────
      // SYNC FINANCIAL STATE
      // ───────────────────────────────────
      await syncDayFinancialState({
        tx,
        dayId: createdDay.id,
        clerkId,
        earnings: validatedData.earnings,
      });

      // ───────────────────────────────────
      // REFETCH HYDRATED AGGREGATE
      // ───────────────────────────────────
      const hydratedDay = await repository.findById({
        id: createdDay.id,
        clerkId,
      });

      if (!hydratedDay) {
        throw new AppError({
          code: APP_ERROR_CODES.FAILED_TO_LOAD_DAY,
          message: ERROR_MESSAGES.FAILED_TO_LOAD_DAY,
          statusCode: 500,
        });
      }

      // ───────────────────────────────────
      // DTO
      // ───────────────────────────────────
      return toDayDto(hydratedDay);
    });
  }
}
